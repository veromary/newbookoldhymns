Dear beta-tester,

 OpusTeX is still a beta-test Version and only dedicated for those, who
 want to work with and - more important - to work on.
 I provide, that you have some experience installing TeX-packages.

 The internals and few externals may change substantially until
 version 1.0 comes up !

 Report bugs either to mutex@gmd.de or to Andreas_Egler@wob.maus.de
 !!! VERY IMPORTANT !!! Tell ALWAYS which version you use.
 (Besides: Saying: "xxx doesn't work." is NOT very helpful.
  Try to extract a SHORT example and provide it too.)

 This version REPLACES all earlier versions.

%% Copyright 1995, 1996 the author of MusiXTeX and OpusTeX and the
%% individual authors.
%% All rights reserved.
%%
%% This file is part of the OpusTeX system.
%% ----------------------------------------
%%
%% This system is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
%%
%%
%% IMPORTANT NOTICE:
%%
%% For error reports in case of UNCHANGED versions see 00readme.txt
%%
%% You are not allowed to change this file.
%%
%% You are allowed to distribute this file under the condition that
%% it is distributed together with all files mentioned in 00readme.txt.
%%
%% If you receive only some of these files from someone, complain!
%%
%% You are NOT ALLOWED to distribute this file alone. You are NOT
%% ALLOWED to take money for the distribution or use of either this
%% file or a changed version, except for a nominal charge for copying
%% etc.

 A list of all current supported and distributed files is appended.

---------------------------------------------------------------------------

The .zip and .tar.gz are packed inclusive pathnames !

Hint: Use a temporary drive or path for unpacking. Move the files to your
paths. Write a batch or shell for this kind of doing. Perhaps you will
need it more often.

===========================================================================
.\00tree
.\mf
    .\mf\opus11.mf
    .\mf\opus13.mf
    .\mf\opus16.mf
    .\mf\opus20.mf
    .\mf\opus24.mf
    .\mf\opusg16.mf
    .\mf\opusg20.mf
    .\mf\opusg24.mf
    .\mf\opusgen.mf
    .\mf\opusggen.mf
    .\mf\opusline.mf
    .\mf\opusnum.mf
    .\mf\opussps.mf
    .\mf\osld11.mf
    .\mf\osld13.mf
    .\mf\osld16.mf
    .\mf\osld16d.mf
    .\mf\osld20.mf
    .\mf\osld20d.mf
    .\mf\osld24.mf
    .\mf\osld24d.mf
    .\mf\oslhd11.mf
    .\mf\oslhd13.mf
    .\mf\oslhd16.mf
    .\mf\oslhd20.mf
    .\mf\oslhd24.mf
    .\mf\oslhgen.mf
    .\mf\oslhu11.mf
    .\mf\oslhu13.mf
    .\mf\oslhu16.mf
    .\mf\oslhu20.mf
    .\mf\oslhu24.mf
    .\mf\oslhz20.mf
    .\mf\oslu11.mf
    .\mf\oslu13.mf
    .\mf\oslu16.mf
    .\mf\oslu16d.mf
    .\mf\oslu20.mf
    .\mf\oslu20d.mf
    .\mf\oslu24.mf
    .\mf\oslu24d.mf
    .\mf\osludgen.mf
    .\mf\oslurgen.mf
    .\mf\oslz20.mf
    .\mf\oslz20d.mf
    .\mf\00conten
.\ps
    .\ps\opusps.doc
    .\ps\opusps.pro
    .\ps\opusps.tex
    .\ps\00conten
.\tfm
    .\tfm\opus11.tfm
    .\tfm\opus13.tfm
    .\tfm\opus16.tfm
    .\tfm\opus20.tfm
    .\tfm\opus24.tfm
    .\tfm\opusg16.tfm
    .\tfm\opusg20.tfm
    .\tfm\opusg24.tfm
    .\tfm\opusline.tfm
    .\tfm\opusnum.tfm
    .\tfm\opussps.tfm
    .\tfm\osld11.tfm
    .\tfm\osld13.tfm
    .\tfm\osld16.tfm
    .\tfm\osld16d.tfm
    .\tfm\osld20.tfm
    .\tfm\osld20d.tfm
    .\tfm\osld24.tfm
    .\tfm\osld24d.tfm
    .\tfm\oslhd11.tfm
    .\tfm\oslhd13.tfm
    .\tfm\oslhd16.tfm
    .\tfm\oslhd20.tfm
    .\tfm\oslhd24.tfm
    .\tfm\oslhu11.tfm
    .\tfm\oslhu13.tfm
    .\tfm\oslhu16.tfm
    .\tfm\oslhu20.tfm
    .\tfm\oslhu24.tfm
    .\tfm\oslhz20.tfm
    .\tfm\oslu11.tfm
    .\tfm\oslu13.tfm
    .\tfm\oslu16.tfm
    .\tfm\oslu16d.tfm
    .\tfm\oslu20.tfm
    .\tfm\oslu20d.tfm
    .\tfm\oslu24.tfm
    .\tfm\oslu24d.tfm
    .\tfm\oslz20.tfm
    .\tfm\oslz20d.tfm
    .\tfm\00conten
.\tex
    .\tex\opusext.tex
    .\tex\opustex.tex
    .\tex\opusadd.tex
    .\tex\opusbar.tex
    .\tex\opusbm.tex
    .\tex\opuscho.tex
    .\tex\opusdat.tex
    .\tex\opusdia.tex
    .\tex\opusgre.tex
    .\tex\opusgui.tex
    .\tex\opushea.tex
    .\tex\opuslit.tex
    .\tex\opusltx.tex
    .\tex\opusmad.tex
    .\tex\opusmed.tex
    .\tex\opusmod.tex
    .\tex\opusper.tex
    .\tex\opuspoi.tex
    .\tex\opussig.tex
    .\tex\opusslu.tex
    .\tex\opusstx.tex
    .\tex\opussys.tex
    .\tex\opustab.tex
    .\tex\opustri.tex
    .\tex\00conten
.\bin
    .\bin\install.sh
    .\bin\opusflex.c
    .\bin\opusflex.c__
    .\bin\00conten
.\doc
    .\doc\history.txt
    .\doc\00conten
.\uti
    .\uti\opustex.sty
    .\uti\00conten
